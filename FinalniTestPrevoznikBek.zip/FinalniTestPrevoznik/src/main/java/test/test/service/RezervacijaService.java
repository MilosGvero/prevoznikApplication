package test.test.service;

import test.test.model.Rezervacija;

public interface RezervacijaService {

	Rezervacija save(Rezervacija rezervacija);
}
